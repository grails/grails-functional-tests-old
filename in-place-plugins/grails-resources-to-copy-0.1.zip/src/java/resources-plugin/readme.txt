Tests whether resources in a plugin's src/java dir. are copied to the
application's "resources" directory.
